from lark import Lark, Transformer, ParseError
from berkeleydb import db
import os

#Set up the directory for the database files
db_directory = "DB"
if not os.path.exists(db_directory):
    os.makedirs(db_directory)

myDB = db.DB()
myDB.open("DB/meta", None, dbtype=db.DB_HASH, flags=db.DB_CREATE)

open_databases = {}


with open('/home/student_202011187/.conda/envs/student_202011187/grammar.lark') as file:
    sql_parser = Lark(file.read(), start="command", lexer="basic")

class DuplicateColumnDefError(Exception):
    pass

class DuplicatePrimaryKeyDefError(Exception):
    pass

class NonExistingColumnDefError(Exception):
    pass

class CharLengthError(Exception):
    pass

class TableExistenceError(Exception):
    pass

class NoSuchTable(Exception):
    pass

# MyTransformer class
# 쿼리를 parsing한 값을 보내 쿼리의 종류에 맞는 결과값을 출력함
# ex) create table query 라면 'CREATE_TABLE' requested 출력
class MyTransformer(Transformer):
    def create_table_query(self, items):
        table_name = items[2].children[0].lower()
        column_definition_iter = items[3].find_data("column_definition")
        table_constraint_iter = items[3].find_data("table_constraint_definition")
        col_name = ''
        col_type = ''
        col_null = ''
        col_key = ''
        pk = ''
        constraint = ''
        pk_flag = 0

        try:
            #같은 이름의 테이블이 없어야함
            #TableExistenceError
            # if os.path.exists("DB/"+table_name)# in myDB.get_dbname():
            #     raise TableExistenceError("DB2020-11187> Create table has failed: table with the same name already exists")

            #else: myDB.open("DB/" + table_name, dbtype=db.DB_HASH, flags=db.DB_CREATE)

            for col_def in column_definition_iter:
                col_key = ''
                col_name += col_def.children[0].children[0].lower() + '|'
                col_type = col_def.children[1].children[0].lower()

                # char data type 은 괄호 안에 표시되는 정수 크기가 1보다 커야함
                # CharLengthError
                # if 'char' in col_type and int(col_type[len("char("):][:-1]) < 1:
                #     raise CharLengthError("Char length should be over 0")
                constraints = [str(child).lower() for child in col_def.children[2:] if child]

                # Identify null and key constraints
                col_null = 'N' if 'not' in constraints and 'null' in constraints else 'Y'

                for table_constraint in table_constraint_iter:
                    if table_constraint.children[0].data == "primary_key_constraint":
                        columns = table_constraint.find_data("column_name")
                        for column in columns:
                            col_key = 'PRI'
                            pk = column.children[0]
                            pk_flag+=1
                            # primary key는 최대 한개
                            # DuplicatePrimaryKeyDefError= Create table has failed: primary key definition is duplicated
                            if pk_flag > 1:
                                raise DuplicatePrimaryKeyDefError("DB2020-11187> Create table has failed: primary key definition is duplicated")

                constraint += str(col_type+"/"+col_null+"/"+col_key) + "|"

            # 컬럼이름은 중복이면 안됨
            # DuplicateColumnDefError= Create table has failed: column definition is duplicated
            if len(set(col_name.split("|"))) != len(col_name.split("|")):
                raise DuplicateColumnDefError("DB2020-11187> Create table has failed: column definition is duplicated")

            # primary key가 있다면 입력된 column 중에 있어야함.
            # NonExistingColumnDefError
            if pk != "" and pk not in col_name.split("|"):
                raise NonExistingColumnDefError("DB2020-11187> Create table has failed: '#colName' does not exist in column definition ")

            myDB.open("DB/" + table_name, None, dbtype=db.DB_HASH, flags=db.DB_CREATE)
            flag = 1

            myDB.put(b'col_name', col_name.encode())
            myDB.put(b'constraint', constraint.encode())
            myDB.put(b'pk', pk.encode())
            open_databases["DB/" + table_name] = myDB

            #myDB.close()
            #table_list = myDB.get(b"table_list").decode()
            #myDB.put('table_list'.encode(), str(table_list+table_name).encode())

                #print(myDB.get(col_name.encode()))
                #print(myDB.get(b"col_name").decode('utf-8').split())
            print(f"DB2020-11187> '{table_name}' table is created")

            # cursor=myDB.cursor()
            # while x := cursor.next():
            #     print(x)

        except Exception as e:
            print(f"DB2020-11187> Error: {str(e)}")

    def drop_table_query(self, items):
        table_name = items[2].children[0].lower()
        try:
            if table_name not in myDB.get_dbname():
                raise NoSuchTable("DB2020-11187> No such table");
            myDB.remove(table_name)

            print(f"DB2020-11187> Table '{table_name}' dropped successfully.")
        except Exception as e:
            print(f"DB2020-11187> Error: {str(e)}")


    def explain_query(self, items):
        print("------------------------")
        table_name = items[1].children[0].lower()
        print(f"table_name [{table_name}]")
        print("column_name | type | null | key")

        try:
            filename = table_name
            if not os.path.exists("DB/"+table_name):        # in myDB.get_dbname():
                raise NoSuchTable("No such table")

            myDB.open("DB/"+filename, dbtype=db.DB_HASH)
            col_name = (myDB.get(b"col_name").decode())[:-1].split("|")
            constraints = (myDB.get(b"constraint").decode())[:-1].split("|")
            for name, con in zip(col_name, constraints):
                print(name +" | "+ con.replace("/", " | ") )

        except Exception as e:
            print(f"DB2020-11187> Error: {str(e)}")

        print("------------------------")

    def describe_query(self, items):
        print("------------------------")
        table_name = items[1].children[0].lower()
        print(f"table_name [{table_name}]")
        print("column_name | type | null | key")

        try:
            filename = table_name
            if "DB/" + table_name not in myDB.get_dbname():
                raise NoSuchTable("DB2020-11187> No such table")
            myDB.open("DB/" + filename, dbtype=db.DB_HASH)
            col_name = (myDB.get(b"col_name").decode())[:-1].split("|")
            constraints = (myDB.get(b"constraint").decode())[:-1].split("|")
            for name, con in zip(col_name, constraints):
                print(name + " | " + con.replace("/", " | "))
            myDB.close()

        except Exception as e:
            print(f"DB2020-11187> Error: {str(e)}")

        print("------------------------")

    def desc_query(self, items):
        print("------------------------")
        table_name = items[1].children[0].lower()
        print(f"table_name [{table_name}]")
        print("column_name | type | null | key")

        try:
            filename = table_name
            if "DB/" + table_name not in myDB.get_dbname():
                raise NoSuchTable("DB2020-11187> No such table")
            myDB.open("DB/" + filename, dbtype=db.DB_HASH)
            col_name = (myDB.get(b"col_name").decode())[:-1].split("|")
            constraints = (myDB.get(b"constraint").decode())[:-1].split("|")
            for name, con in zip(col_name, constraints):
                print(name + " | " + con.replace("/", " | "))

            myDB.close()

        except Exception as e:
            print(f"DB2020-11187> Error: {str(e)}")

        print("------------------------")

    def insert_query(self, items):
        table_name = items[2].children[0].lower()
        values = items[5].find_data("comparable_value")
        if "DB/" + table_name not in myDB.get_dbname():
            raise NoSuchTable("DB2020-11187> No such table")

        try:
            #db_path = os.path.join("DB", table_name + '.db')
            myDB.open("DB/"+table_name, dbtype=db.DB_HASH)
            data = [val.children[0] for val in values]
            #type check,
            #pri key check
            pk = myDB.get(b"pk")

            myDB.put(data[0].encode(), data[1].encode())

            print(f"DB2020-11187> 1 row inserted in table '{table_name}'.")
            cursor = myDB.cursor()
            while x := cursor.next():
                print(x)


        except Exception as e:
            print(f"DB2020-11187> Error: {str(e)}")

    def delete_query(self, items):
        print("DB2020-11187> 'DELETE' requested")

    def select_query(self, items):
        try:
            table_name = items[2].children[0].children[1].children[0].children[0].children[0].lower()

            filename = table_name
            myDB.open("DB/"+filename, None, dbtype=db.DB_HASH)

            #Getting column names from the database
            col_names = myDB.get('col_name'.encode()).decode().split("|")[:-1]

            #Print column names,,
            print("+{}+".format("-" * (15 * len(col_names) + len(col_names) - 1)))
            for col in col_names:
                print("|{:^15}".format(col), end="")
            print("|")
            print("+{}+".format("-" * (15 * len(col_names) + len(col_names) - 1)))


            data = []
            cursor = myDB.cursor()
            while x := cursor.next():
                if x[0].decode() != 'col_name' and x[0].decode() != 'constraint' and x[0].decode() != 'pk':
                    print(x)
            myDB.close()

        except Exception as e:
            print(f"DB2020-11187> Error: {str(e)}")

    def show_tables_query(self, items):
        print("------------------------")
        try:
            table_names = myDB.get_dbname()
            #print(table_names)

            if table_names:
                for name in table_names:
                    if name != None:
                        print(name)

        except Exception as e:
            print(f"DB2020-11187> Error: {str(e)}")

        print("------------------------")

    def update_table_query(self, items):
        print("DB2020-11187> 'UPDATE' requested")


# 입력을 처리하는 부분
exit_ = False  # exit이 실행되었는지 확인하는 exit_ 변수
while exit_ != 1:
    first_prompt = True  # 처음 한 번만 프롬프트를 표시하기 위한 플래그

    # 입력 중간에 개행이 입력되어도 구문이 끝난 것이 아니라면 계속 입력을 받도록 input 값을 관리함
    input_lines = ""
    while not input_lines.endswith(';\n'):
        user_input = input("DB2020-11187> " if first_prompt else "")
        first_prompt = False
        input_lines += user_input + "\n"

    queries = []  # 입력된 구문(들)을 semicolon(;)을 기준으로 분리하여 쿼리 관리
    queries = input_lines.split(";")

    for q in queries:
        error_flag = False  # 입력 중에 Syntax error가 존재하는지 확인하는 플래그
        # exit이 입력되었다면 종료
        if q.strip() == "exit":
            exit_ = True
            break
        # parsing -> 오류 확인 -> 결과 출력
        elif q.strip():
            try:
                parsed_output = sql_parser.parse(q.strip() + ";")
                #print(parsed_output.pretty())
                MyTransformer().transform(parsed_output)

            except ParseError as e:
                # 파싱 오류 처리
                error_flag = True
                print("DB2020-11187> Syntax Error")
        # error 발생 시 종료
        if error_flag:
            queries = []
            break
